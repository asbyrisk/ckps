<?php

namespace App\Http\Controllers;

use App\Models\Asn;
use App\Models\AsnTraining;
use App\Models\AsnUnitHistory;
use App\Models\Pelatihan;
use App\Models\Unit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AsnController extends Controller
{
    public function index(Request $request)
    {
        $query = Asn::query()
            ->with('unit')
            ->withCount([
                'trainings',
                'competencies',
            ]);

        if ($request->filled('search')) {
            $search = trim($request->string('search')->toString());

            $query->where(function ($q) use ($search) {
                $q->where('nip', 'like', "%{$search}%")
                    ->orWhere('name', 'like', "%{$search}%")
                    ->orWhere('position', 'like', "%{$search}%")
                    ->orWhere('rank', 'like', "%{$search}%")
                    ->orWhereHas('unit', function ($unitQuery) use ($search) {
                        $unitQuery->where('name', 'like', "%{$search}%");
                    });
            });
        }

        if ($request->status === 'sudah') {
            $query->whereHas('trainings', function ($q) {
                $q->whereIn('asn_trainings.status', AsnTraining::completedStatuses());
            });
        }

        if ($request->status === 'belum') {
            $query->where(function ($q) {
                $q->whereDoesntHave('trainings')
                    ->orWhereHas('trainings', function ($trainingQuery) {
                        $trainingQuery->whereNotIn(
                            'asn_trainings.status',
                            AsnTraining::completedStatuses()
                        );
                    });
            });
        }

        if ($request->status === 'diusulkan') {
            $query->whereHas('trainings', function ($q) {
                $q->where('asn_trainings.status', 'diusulkan');
            });
        }

        $asn = $query
            ->orderBy('name')
            ->paginate(20)
            ->withQueryString();

        return view('asn.index', compact('asn'));
    }

    public function create()
    {
        $units = Unit::query()
            ->orderBy('name')
            ->get();

        return view('asn.create', compact('units'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'nip' => ['required', 'string', 'max:30', 'unique:asns,nip'],
            'name' => ['required', 'string', 'max:255'],
            'position' => ['nullable', 'string', 'max:255'],
            'rank' => ['nullable', 'string', 'max:50'],
            'unit_id' => ['nullable', 'exists:units,id'],
        ]);

        $asn = Asn::create($validated);

        return redirect()
            ->route('asn.show', $asn)
            ->with('success', 'Data ASN berhasil ditambahkan.');
    }

    public function show(Asn $asn)
    {
        $asn->load([
            'unit',
            'competencies',
            'unitHistories.fromUnit',
            'unitHistories.toUnit',
            'unitHistories.changedBy',
        ]);

        $trainings = Pelatihan::query()
            ->orderBy('name')
            ->get();

        $statusRows = AsnTraining::query()
            ->where('asn_id', $asn->id)
            ->orderByDesc('id')
            ->get();

        $trainingStatus = $statusRows
            ->groupBy('training_id')
            ->map(function ($rows) {
                $manual = $rows
                    ->filter(function ($row) {
                        return $row->source_sheet === 'manual'
                            && is_null($row->year);
                    })
                    ->sortByDesc('id')
                    ->first();

                if ($manual) {
                    return AsnTraining::normalizeStatus($manual->status);
                }

                return $rows->contains(function ($row) {
                    return in_array(
                        strtolower(trim((string) $row->status)),
                        AsnTraining::completedStatuses(),
                        true
                    );
                }) ? 'sudah' : 'belum';
            });

        return view('asn.show', compact(
            'asn',
            'trainings',
            'trainingStatus'
        ));
    }

    public function edit(Asn $asn)
    {
        $units = Unit::query()
            ->orderBy('name')
            ->get();

        return view('asn.edit', compact('asn', 'units'));
    }

    public function update(Request $request, Asn $asn)
    {
        $validated = $request->validate([
            'nip' => [
                'required',
                'string',
                'max:30',
                'unique:asns,nip,' . $asn->id,
            ],
            'name' => ['required', 'string', 'max:255'],
            'position' => ['nullable', 'string', 'max:255'],
            'rank' => ['nullable', 'string', 'max:50'],
            'unit_id' => ['nullable', 'exists:units,id'],
        ]);

        $asn->update($validated);

        return redirect()
            ->route('asn.show', $asn)
            ->with('success', 'Data ASN berhasil diperbarui.');
    }

    public function updateTrainingStatus(
        Request $request,
        Asn $asn,
        Pelatihan $pelatihan
    ) {
        $validated = $request->validate([
            'status' => ['required', 'in:sudah,belum,diusulkan'],
        ]);

        DB::transaction(function () use ($asn, $pelatihan, $validated) {
            $manual = AsnTraining::query()
                ->where('asn_id', $asn->id)
                ->where('training_id', $pelatihan->id)
                ->whereNull('year')
                ->where('source_sheet', 'manual')
                ->latest('id')
                ->first();

            if (!$manual) {
                $manual = new AsnTraining([
                    'asn_id' => $asn->id,
                    'training_id' => $pelatihan->id,
                    'year' => null,
                    'source_sheet' => 'manual',
                ]);
            }

            $manual->status = $validated['status'];
            $manual->save();
        });

        $label = AsnTraining::statusLabel($validated['status']);

        return redirect()
            ->route('asn.show', $asn)
            ->with(
                'success',
                "Status " . $pelatihan->name . " berhasil diubah menjadi: {$label}."
            );
    }

    public function cancelUnitHistory(Request $request, Asn $asn, AsnUnitHistory $history)
    {
        if ((int) $history->asn_id !== (int) $asn->id) {
            abort(404);
        }

        $validated = $request->validate([
            'cancellation_reason' => ['required', 'string', 'max:2000'],
        ]);

        try {
            DB::transaction(function () use ($asn, $history, $validated) {
            $history = AsnUnitHistory::query()
                ->whereKey($history->id)
                ->lockForUpdate()
                ->firstOrFail();

            if (($history->status ?: 'aktif') !== 'aktif') {
                throw new \RuntimeException('Riwayat perpindahan tersebut sudah dibatalkan.');
            }

            $latestActive = AsnUnitHistory::query()
                ->where('asn_id', $asn->id)
                ->where(function ($query) {
                    $query->whereNull('status')->orWhere('status', 'aktif');
                })
                ->orderByDesc('id')
                ->lockForUpdate()
                ->first();

            if (!$latestActive || (int) $latestActive->id !== (int) $history->id) {
                throw new \RuntimeException(
                    'Riwayat ini tidak dapat dibatalkan karena sudah ada perpindahan aktif setelahnya. Batalkan perpindahan terbaru terlebih dahulu.'
                );
            }

            if ((int) ($asn->unit_id ?? 0) !== (int) ($history->to_unit_id ?? 0)) {
                throw new \RuntimeException(
                    'Unit kerja ASN saat ini tidak lagi sesuai dengan tujuan riwayat tersebut. Riwayat tidak dibatalkan untuk mencegah data menjadi tidak konsisten.'
                );
            }

            $asn->update([
                'unit_id' => $history->from_unit_id,
            ]);

                $history->update([
                    'status' => 'dibatalkan',
                    'canceled_at' => now(),
                    'canceled_by' => auth()->id(),
                    'cancellation_reason' => $validated['cancellation_reason'],
                ]);
            });
        } catch (\RuntimeException $e) {
            return redirect()
                ->route('asn.show', $asn)
                ->with('error', $e->getMessage());
        }

        return redirect()
            ->route('asn.show', $asn)
            ->with('success', 'Perpindahan dibatalkan. Unit kerja ASN dikembalikan ke unit sebelumnya dan riwayat tetap disimpan sebagai jejak koreksi.');
    }

    public function transferUnit(Request $request, Asn $asn)
    {
        $validated = $request->validate([
            'unit_id' => ['required', 'exists:units,id'],
            'effective_date' => ['nullable', 'date'],
            'reason' => ['nullable', 'string', 'max:255'],
            'note' => ['nullable', 'string', 'max:2000'],
        ]);

        DB::transaction(function () use ($asn, $validated) {
            $fromUnitId = $asn->unit_id;
            $toUnitId = (int) $validated['unit_id'];

            if ($fromUnitId === $toUnitId) {
                return;
            }

            AsnUnitHistory::create([
                'asn_id' => $asn->id,
                'from_unit_id' => $fromUnitId,
                'to_unit_id' => $toUnitId,
                'effective_date' => $validated['effective_date'] ?? now()->toDateString(),
                'reason' => $validated['reason'] ?? 'Penugasan / perpindahan unit kerja',
                'note' => $validated['note'] ?? null,
                'changed_by' => auth()->id(),
            ]);

            $asn->update(['unit_id' => $toUnitId]);
        });

        return redirect()->route('asn.show', $asn)
            ->with('success', 'Unit kerja ASN berhasil diperbarui dan riwayat perpindahan disimpan.');
    }

    public function destroy(Asn $asn)
    {
        DB::transaction(function () use ($asn) {
            DB::table('asn_trainings')
                ->where('asn_id', $asn->id)
                ->delete();

            DB::table('asn_kompetensi')
                ->where('asn_id', $asn->id)
                ->delete();

            $asn->delete();
        });

        return redirect()
            ->route('asn.index')
            ->with('success', 'Data ASN berhasil dihapus.');
    }
}
