<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AsnUnitHistory extends Model
{
    protected $table = 'asn_unit_histories';

    protected $fillable = [
        'asn_id', 'from_unit_id', 'to_unit_id', 'effective_date',
        'reason', 'note', 'changed_by',
    ];

    protected $casts = [
        'effective_date' => 'date',
    ];

    public function fromUnit(): BelongsTo { return $this->belongsTo(Unit::class, 'from_unit_id'); }
    public function toUnit(): BelongsTo { return $this->belongsTo(Unit::class, 'to_unit_id'); }
    public function changedBy(): BelongsTo { return $this->belongsTo(User::class, 'changed_by'); }
}
