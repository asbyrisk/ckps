<?php

namespace App\Http\Controllers;

use App\Models\ImportBatch;
use App\Services\ExcelImporterService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Throwable;

class ImportController extends Controller
{
    public function index()
    {
        $imports = ImportBatch::query()
            ->latest()
            ->paginate(10);

        return view('import.index', compact('imports'));
    }

    public function store(Request $request, ExcelImporterService $importer): RedirectResponse
    {
        $validated = $request->validate([
            'file' => [
                'required',
                'file',
                'max:51200',
                'extensions:xlsx,xls,csv',
            ],
        ], [
            'file.required' => 'Pilih file Excel terlebih dahulu.',
            'file.extensions' => 'File harus berformat XLSX, XLS, atau CSV.',
            'file.max' => 'Ukuran file maksimal 50 MB.',
        ]);

        $path = $validated['file']->store('imports');
        $absolutePath = Storage::path($path);

        try {
            $extension = strtolower($validated['file']->getClientOriginalExtension());

            if ($extension === 'xlsx' && !class_exists('ZipArchive')) {
                throw new \RuntimeException(
                    'Ekstensi PHP ZIP belum aktif. Aktifkan extension=zip pada php.ini lalu restart PHP/Apache sebelum mengimpor file XLSX.'
                );
            }

            // Validasi bahwa file benar-benar dapat dikenali PhpSpreadsheet sebelum
            // transaksi database dimulai. Ini membuat pesan error upload lebih jelas.
            IOFactory::identify($absolutePath);

            $batch = $importer->import($absolutePath);
            $batch->update(['filename' => $validated['file']->getClientOriginalName()]);
        } catch (Throwable $e) {
            Storage::delete($path);
            report($e);

            $message = 'File berhasil diterima tetapi gagal diproses oleh aplikasi. ' .
                'File sumber Anda valid, jadi masalah kemungkinan berasal dari struktur database atau konfigurasi PHP/PhpSpreadsheet.';

            if (app()->environment('local')) {
                $message .= ' Detail: ' . mb_substr($e->getMessage(), 0, 240);
            }

            if (str_contains(strtolower($e->getMessage()), 'zip')) {
                $message .= ' Jika menggunakan XLSX, simpan ulang file sebagai .xlsx lalu unggah kembali.';
            }

            return back()
                ->withInput()
                ->withErrors(['file' => $message]);
        }

        Storage::delete($path);

        return redirect()
            ->route('import.index')
            ->with('success', "Import {$batch->filename} berhasil. Data ASN, pelatihan, dan kompetensi telah disinkronkan.");
    }
}
