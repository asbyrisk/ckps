# CKPS Mapping - Revisi Final

Patch ini dibuat dari project ZIP yang terakhir dikirim.

## Perbaikan utama

1. Error `AsnTraining::statusLabel()` diperbaiki.
2. Status pelatihan mendukung:
   - Sudah mengikuti
   - Belum mengikuti
   - Diusulkan
3. Import Excel tidak lagi menulis relasi kompetensi ke tabel legacy `kompetensi_pelatihan`.
   Relasi aplikasi sekarang memakai `training_kompetensi`, sesuai model `Pelatihan` dan `Kompetensi`.
   Ini memperbaiki error FK 1452 pada `kompetensi_pelatihan`.
4. Pembacaan identitas ASN diperbaiki untuk beberapa layout Excel:
   - D=Jabatan, E=Unit Kerja, F=Golongan
   - D=Pangkat/Golongan, E=Jabatan, F=Unit Kerja
   - D=Pangkat/Golongan, E=Unit Kerja, F=Golongan
   - D=Jabatan, E=Unit Kerja, F=Pangkat/Golongan
5. Golongan dinormalisasi menjadi format seperti `IV/a`, `III/c`.
6. Jabatan panjang tidak lagi dimasukkan ke kolom `rank`.
7. Unit kerja seperti `Balai ...`, `Direktorat ...`, `Sekretariat ...` dipisahkan dari jabatan berdasarkan isi nilai, bukan hanya nama header.
8. Import tidak menghapus data jabatan/pangkat/unit yang sudah benar ketika sheet tertentu tidak membawa identitas lengkap.
9. Nama pelatihan numerik seperti `1`, `10`, `11` dibersihkan; kode internal `PLT-001`, dst. dibuat jika sumber Excel tidak menyediakan kode.
10. Riwayat perpindahan unit ASN tetap tersedia melalui halaman Detail ASN.
11. Pagination Data ASN sudah menampilkan maksimal 5 nomor halaman di sekitar halaman aktif.

## Cara memasang

Timpa folder berikut pada project yang sedang dipakai:

- `app/`
- `resources/`
- `routes/`
- `database/migrations/`

Jangan menimpa `.env` dan jangan hapus `vendor/`.

Kemudian:

```bash
php artisan optimize:clear
php artisan migrate
```

Jangan gunakan `php artisan migrate:fresh`.

Setelah aplikasi bisa dibuka, import kembali file Excel sumber yang sama agar Jabatan, Pangkat, dan Unit Kerja yang sudah telanjur tersimpan salah diperbarui.

## Catatan

Migration `asn_unit_histories` dan `training_kompetensi` dibuat aman jika tabelnya sudah ada.

Password registrasi tetap menggunakan aturan Laravel:
minimal 8 karakter + huruf besar/kecil + angka + simbol.

## Patch lanjutan 20 Agustus 2026

### Kompetensi tampil sebagai `=VLOOKUP(...)`

Importer sekarang membaca **hasil perhitungan formula Excel** melalui `getCalculatedValue()` dan tidak menyimpan teks rumus mentah. Artefak kompetensi lama yang kode/nama-nya diawali `=` atau `#N/A` juga dibersihkan saat import ulang.

Setelah memasang patch, **jalankan import Excel sekali lagi** agar data kompetensi yang telanjur salah dibersihkan dan diisi ulang dari hasil formula.

### Perpindahan unit ASN

Detail ASN sekarang memiliki bagian **Penugasan / Perpindahan Unit Kerja** untuk memindahkan ASN dari unit A ke unit B. Setiap perpindahan menyimpan:

- unit asal;
- unit tujuan;
- tanggal berlaku;
- alasan perubahan;
- catatan;
- user yang melakukan perubahan.

Riwayat ditampilkan langsung pada Detail ASN.

### Jika `asn_unit_histories` sudah ada

Migration `2026_08_20_100000_create_asn_unit_histories_table.php` aman bila tabel sudah ada. Migration normalisasi tambahan juga menangani skema lama `previous_unit_id/new_unit_id/notes` bila pernah terbentuk.

Gunakan:

```bash
php artisan optimize:clear
php artisan migrate
```

Jika muncul `Nothing to migrate`, itu berarti semua migration yang dikenali Laravel sudah tercatat. Jangan gunakan `migrate:fresh` karena akan menghapus data.

## Koreksi Riwayat Perpindahan ASN

Tambahan revisi ini membuat riwayat perpindahan unit kerja dapat **dikoreksi tanpa menghapus jejak history**.

### Cara kerja

1. Pada Detail ASN, setiap riwayat perpindahan aktif memiliki tombol **Koreksi**.
2. Klik **Koreksi**, isi alasan koreksi, lalu konfirmasi.
3. Sistem mengembalikan ASN ke `from_unit_id` dari riwayat tersebut.
4. Record history tidak dihapus. Record diberi status `dibatalkan`, waktu pembatalan, user yang melakukan koreksi, dan alasan koreksi.
5. Hanya perpindahan aktif yang paling baru yang boleh dibatalkan. Jika sudah ada perpindahan berikutnya, perpindahan terbaru harus dikoreksi terlebih dahulu agar urutan history tetap konsisten.
6. Jika unit ASN saat ini sudah tidak sama dengan tujuan history, sistem menolak koreksi untuk mencegah data menjadi tidak konsisten.

### Migration

Jalankan di project utama:

```bash
php artisan migrate
```

Migration tambahan: `2026_08_20_120000_add_correction_to_asn_unit_histories.php`.

Migration dibuat aman untuk database yang sudah memiliki tabel `asn_unit_histories`; kolom hanya ditambahkan jika belum tersedia.
