@extends('layouts.app')

@section('title', 'Audit Trail - CKPS Mapping')

@section('content')
<div class="page">
    <div class="page-header-row">
        <div>
            <div class="kicker">PENGAWASAN SISTEM</div>
            <h1>Audit Trail</h1>
            <p class="page-description">Catatan perubahan data untuk mengetahui siapa, kapan, dan apa yang diubah.</p>
        </div>
        <span class="table-count">{{ $logs->total() }} aktivitas</span>
    </div>

    <div class="panel" style="margin-bottom:20px;">
        <div class="panel-body">
            <form method="GET" class="filter-row" style="display:grid;grid-template-columns:1fr 220px auto;gap:10px;">
                <input type="text" name="search" value="{{ request('search') }}" class="search-input" placeholder="Cari pengguna, aktivitas, atau IP...">
                <select name="action" class="form-control">
                    <option value="">Semua aktivitas</option>
                    @foreach($actions as $action)
                        <option value="{{ $action }}" {{ request('action') === $action ? 'selected' : '' }}>{{ ucfirst(str_replace('_', ' ', $action)) }}</option>
                    @endforeach
                </select>
                <button class="btn" type="submit">Filter</button>
            </form>
        </div>
    </div>

    <div class="panel">
        <div class="panel-header">
            <h2>Riwayat aktivitas</h2>
            <p>Riwayat tidak dihapus ketika data dikoreksi sehingga perubahan tetap dapat ditelusuri.</p>
        </div>
        <div class="audit-list">
            @forelse($logs as $log)
                <div class="audit-row">
                    <div class="audit-icon">✓</div>
                    <div class="audit-main">
                        <strong>{{ $log->description }}</strong>
                        <div class="audit-meta">
                            {{ $log->user?->name ?: 'Sistem' }} · {{ $log->created_at?->format('d/m/Y H:i:s') }} · {{ $log->ip_address ?: '-' }}
                        </div>
                        <div class="audit-tag-row">
                            <span class="status-pill audit-action">{{ ucfirst(str_replace('_', ' ', $log->action)) }}</span>
                            <span class="status-pill audit-target">{{ $log->auditableLabel() }}</span>
                        </div>
                        @if($log->old_values || $log->new_values)
                            <details class="audit-details">
                                <summary>Lihat detail perubahan</summary>
                                <div class="audit-json-grid">
                                    <div>
                                        <b>Sebelum</b>
                                        <pre>{{ json_encode($log->old_values, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE) }}</pre>
                                    </div>
                                    <div>
                                        <b>Sesudah</b>
                                        <pre>{{ json_encode($log->new_values, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE) }}</pre>
                                    </div>
                                </div>
                            </details>
                        @endif
                    </div>
                </div>
            @empty
                <div class="empty-state">
                    <div class="empty-icon">🧾</div>
                    <strong>Belum ada aktivitas tercatat.</strong>
                    Perubahan data yang dilakukan setelah audit trail aktif akan muncul di sini.
                </div>
            @endforelse
        </div>
        @if($logs->hasPages())
            <div class="pagination-wrap">{{ $logs->links() }}</div>
        @endif
    </div>
</div>
@endsection
