<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AuditLog extends Model
{
    protected $fillable = [
        'user_id',
        'action',
        'auditable_type',
        'auditable_id',
        'description',
        'old_values',
        'new_values',
        'ip_address',
        'user_agent',
    ];

    protected $casts = [
        'old_values' => 'array',
        'new_values' => 'array',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function auditableLabel(): string
    {
        return match ($this->auditable_type) {
            Asn::class => 'ASN',
            AsnUnitHistory::class => 'Riwayat perpindahan ASN',
            AsnTraining::class => 'Status pelatihan ASN',
            ImportBatch::class => 'Import Excel',
            default => $this->auditable_type ? class_basename($this->auditable_type) : 'Sistem',
        };
    }
}
